package Database;

public class SellerByItem {
    public String item;
    public int coins;

    public SellerByItem(String item, int coins) {
        this.item = item;
        this.coins = coins;
    }
}
