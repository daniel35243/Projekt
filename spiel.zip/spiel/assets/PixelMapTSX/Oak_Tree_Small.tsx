<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Oak_Tree_Small" tilewidth="16" tileheight="16" tilecount="18" columns="6">
 <image source="../PixelMapPNGs/Outdoor decoration/Oak_Tree_Small.png" width="96" height="48"/>
</tileset>
