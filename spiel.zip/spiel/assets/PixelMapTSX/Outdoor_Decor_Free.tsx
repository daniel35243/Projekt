<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Outdoor_Decor_Free" tilewidth="16" tileheight="16" tilecount="84" columns="7">
 <image source="../PixelMapPNGs/Outdoor decoration/Items.png" width="112" height="192"/>
</tileset>
