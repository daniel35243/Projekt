<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="FarmLand_Tile" tilewidth="16" tileheight="16" tilecount="9" columns="3">
 <image source="../PixelMapPNGs/Tiles/FarmLand_Tile.png" width="48" height="48"/>
</tileset>
