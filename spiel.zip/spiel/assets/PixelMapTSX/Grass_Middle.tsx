<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Grass_Middle" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="../PixelMapPNGs/Tiles/Grass_Middle.png" width="16" height="16"/>
</tileset>
