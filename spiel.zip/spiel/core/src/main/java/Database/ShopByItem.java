package Database;

public class ShopByItem {
    public String item;
    public int coins;

    public ShopByItem(String item, int coins) {
        this.item = item;
        this.coins = coins;
    }
}
