package Pflanzen;

public class Pflanze {
}
