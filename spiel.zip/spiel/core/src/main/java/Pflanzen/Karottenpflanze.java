package Pflanzen;

public class Karottenpflanze {
}
