package io.github.FarmLife;

import Database.AndroidDatabaseLogik;
import Database.InventorySlotDB;
import io.github.FarmLife.InventorySlot;
import io.github.FarmLife.Main;

public class SaveGame {

    private final AndroidDatabaseLogik db;
    private final InventorySlot[] inventory;

    public GameSave(Main game, InventorySlot[] inventory) {
        this.db = game.db;
        this.inventory = inventory;
    }

    public void saveInventory() {
        for (int i = 1; i < inventory.length; i++) {
            InventorySlot slot = inventory[i];

            if (slot.item != null) {
                InventorySlotDB slotDB = new InventorySlotDB(
                    i + 1,
                    slot.item.getName(),  // getName() muss dein Item zurückgeben (z. B. "wood")
                    slot.itemCount
                );
                db.updateInventorySlot(slotDB);
            }
        }
    }
}
