package Items;

public class Gießkanne {
}
