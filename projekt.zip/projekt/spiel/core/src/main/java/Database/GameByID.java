package Database;

public class GameByID {
    public int ID;
    public int Coins;
    public int Level;
    public int XP;

    public GameByID(int ID, int Coins, int Level, int XP) {
        this.ID = ID;
        this.Coins = Coins;
        this.Level = Level;
        this.XP = XP;
    }
}
